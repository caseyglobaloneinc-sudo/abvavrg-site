import * as React from "react";
import { cn } from "@/lib/utils";

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea({ className, ...props }, ref) {
  return (
    <textarea
      ref={ref}
      className={cn(
        "w-full rounded-xl border border-black/10 bg-white px-3 py-2 text-sm shadow-sm outline-none placeholder:text-neutral-400 focus:ring-2 focus:ring-amber-400 dark:border-white/10 dark:bg-neutral-900",
        className
      )}
      {...props}
    />
  );
});
