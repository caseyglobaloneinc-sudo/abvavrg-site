import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ABVAVRG — Above Average Brands",
  description: "We build and incubate brands that punch above their weight.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
