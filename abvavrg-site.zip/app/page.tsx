'use client';

import React, { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Building2,
  FlaskConical,
  Menu,
  Moon,
  Sparkles,
  Sun,
  Truck
} from "lucide-react";

export default function Page() {
  const [dark, setDark] = useState(true);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (dark) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  }, [dark]);

  const navItems = useMemo(
    () => [
      { href: "#about", label: "About" },
      { href: "#ventures", label: "Ventures" },
      { href: "#services", label: "Services" },
      { href: "#contact", label: "Contact" }
    ],
    []
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-neutral-50 via-white to-neutral-100 dark:from-neutral-950 dark:via-neutral-950 dark:to-neutral-900 text-neutral-900 dark:text-white">
      <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-20 left-1/2 h-72 w-[72rem] -translate-x-1/2 rounded-full bg-gradient-to-r from-amber-300/40 to-amber-500/30 blur-3xl dark:from-amber-500/20 dark:to-amber-400/10"/>
      </div>

      <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-neutral-950/50 border-b border-black/5 dark:border-white/10">
        <div className="container">
          <div className="flex h-16 items-center justify-between">
            <a href="#home" className="group inline-flex items-center gap-2">
              <div className="grid h-8 w-8 place-items-center rounded-xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 shadow-sm">
                <Sparkles className="h-4 w-4" />
              </div>
              <span className="text-lg font-semibold tracking-widest">ABVAVRG</span>
            </a>

            <nav className="hidden items-center gap-6 md:flex">
              {navItems.map((i) => (
                <a key={i.href} href={i.href} className="text-sm font-medium text-neutral-600 hover:text-neutral-900 dark:text-neutral-300 dark:hover:text-white">
                  {i.label}
                </a>
              ))}
              <Button className="ml-2">
                <a href="#contact">Work with us</a>
              </Button>
              <Button variant="ghost" aria-label="Toggle theme" onClick={() => setDark((d) => !d)}>
                {dark ? <Sun className="h-4 w-4"/> : <Moon className="h-4 w-4"/>}
              </Button>
            </nav>

            <div className="flex items-center gap-2 md:hidden">
              <Button variant="ghost" aria-label="Toggle theme" onClick={() => setDark((d) => !d)}>
                {dark ? <Sun className="h-5 w-5"/> : <Moon className="h-5 w-5"/>}
              </Button>
              <Button variant="ghost" aria-label="Open menu" onClick={() => setOpen((x) => !x)}>
                <Menu className="h-6 w-6" />
              </Button>
            </div>
          </div>
        </div>

        {open && (
          <div className="md:hidden border-t border-black/5 dark:border-white/10">
            <div className="container py-3 flex flex-col gap-3">
              {navItems.map((i) => (
                <a key={i.href} href={i.href} className="text-sm font-medium text-neutral-700 dark:text-neutral-300" onClick={() => setOpen(false)}>
                  {i.label}
                </a>
              ))}
              <Button onClick={() => setOpen(false)}>
                <a href="#contact">Work with us</a>
              </Button>
            </div>
          </div>
        )}
      </header>

      <section id="home" className="relative overflow-hidden">
        <div className="container pt-16 pb-24 sm:pt-20 sm:pb-28">
          <div className="grid items-center gap-12 md:grid-cols-2">
            <div>
              <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-400/10 px-3 py-1 text-xs font-semibold tracking-wide text-amber-700 dark:text-amber-300">
                Built to be above average
              </p>
              <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight">
                We build and incubate brands that punch above their weight.
              </h1>
              <p className="mt-5 text-neutral-600 dark:text-neutral-300 leading-relaxed">
                ABVAVRG is an umbrella company creating durable, cash-flowing businesses—from consumer goods to services and media. We obsess over operations, design, and storytelling so each venture can stand on its own.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Button>
                  <a href="#contact" className="inline-flex items-center gap-2">
                    Start a project <ArrowRight className="h-4 w-4"/>
                  </a>
                </Button>
                <Button variant="outline">
                  <a href="#ventures" className="inline-flex items-center gap-2">
                    Explore ventures <ArrowUpRight className="h-4 w-4"/>
                  </a>
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -right-10 -top-10 h-64 w-64 rounded-full bg-gradient-to-tr from-amber-400/40 to-fuchsia-400/40 blur-3xl"/>
              <Card className="relative border-black/5 bg-white/70 backdrop-blur dark:bg-neutral-900/50 dark:border-white/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Sparkles className="h-5 w-5"/> What we do
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid gap-4">
                  <Feature
                    icon={<Building2 className="h-5 w-5"/>}
                    title="Company Building"
                    text="We spin up brands under a single, risk-aware holding structure and shared back office."
                  />
                  <Feature
                    icon={<FlaskConical className="h-5 w-5"/>}
                    title="Rapid Experimentation"
                    text="Tested playbooks for product-market fit, media, and monetization across niches."
                  />
                  <Feature
                    icon={<BookOpen className="h-5 w-5"/>}
                    title="Story & Design"
                    text="Premium branding, photo/video, and copy that make small teams feel enterprise."
                  />
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <section id="ventures" className="py-20">
        <div className="container">
          <div className="mb-10 flex items-end justify-between gap-4">
            <div>
              <h2 className="text-3xl font-bold">Ventures</h2>
              <p className="mt-2 text-neutral-600 dark:text-neutral-300">A few of the brands and projects under the ABVAVRG banner.</p>
            </div>
            <a href="#contact" className="text-sm font-medium text-amber-700 hover:underline inline-flex items-center gap-1 dark:text-amber-300">
              Pitch your idea <ArrowUpRight className="h-4 w-4"/>
            </a>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <Venture
              icon={<FlaskConical className="h-6 w-6"/>}
              name="ABVAVRG Fragrance Co."
              blurb="Signature colognes crafted with bold, durable scent profiles and minimalist packaging."
              tags={["DTC", "Retail", "Branding"]}
            />
            <Venture
              icon={<Truck className="h-6 w-6"/>}
              name="ABVAVRG Haul & Junk Removal"
              blurb="White-glove junk removal with transparent pricing and next‑day service."
              tags={["Local", "Services", "Ops"]}
            />
            <Venture
              icon={<BookOpen className="h-6 w-6"/>}
              name="Boots & Bibles"
              blurb="A media project sharing faith-forward messages and visuals across social platforms."
              tags={["Media", "Content", "Community"]}
            />
            <Venture
              icon={<Building2 className="h-6 w-6"/>}
              name="ABVAVRG Properties"
              blurb="Value-add real estate plays and property services focused on clean operations."
              tags={["Real Estate", "Ops"]}
            />
            <PlaceholderVenture />
            <PlaceholderVenture />
          </div>
        </div>
      </section>

      <section id="services" className="py-20">
        <div className="container">
          <div className="mb-10">
            <h2 className="text-3xl font-bold">How we help</h2>
            <p className="mt-2 max-w-2xl text-neutral-600 dark:text-neutral-300">
              Partner with us as a co-founder, or hire our team a la carte for branding, media, go-to-market, and operational systems.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Service title="Brand Identity & Web" points={["Naming, logo, and design system", "High-converting landing pages", "Social kits & content templates"]}/>
            <Service title="Media & Growth" points={["Photo & video ads", "UGC & short‑form workflow", "SEO + local services growth"]}/>
            <Service title="Ops & Automation" points={["Playbooks & SOPs", "Booking & CRM setup", "AI agents & no‑code automations"]}/>
          </div>
        </div>
      </section>

      <section id="contact" className="py-20">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold">Let’s build something above average</h2>
              <p className="mt-3 text-neutral-600 dark:text-neutral-300 max-w-xl">
                Tell us about your idea, or ask about partnering on one of ours. We typically reply within one business day.
              </p>
              <div className="mt-6 grid gap-3 text-sm text-neutral-700 dark:text-neutral-300">
                <a className="underline" href="mailto:hello@abvavrg.com?subject=Project%20inquiry%20from%20abvavrg.com">hello@abvavrg.com</a>
                <span className="opacity-80">Palm Desert, CA</span>
              </div>
            </div>
            <Card className="border-black/5 bg-white/70 backdrop-blur dark:bg-neutral-900/50 dark:border-white/10">
              <CardHeader>
                <CardTitle>Quick message</CardTitle>
              </CardHeader>
              <CardContent>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const data = new FormData(e.currentTarget as HTMLFormElement);
                    const body = encodeURIComponent(
                      [`Name: ${data.get("name")}`, `Email: ${data.get("email")}`, "", `${data.get("message")}`].join("\n")
                    );
                    const mailto = `mailto:hello@abvavrg.com?subject=Website%20inquiry&body=${body}`;
                    window.location.href = mailto;
                  }}
                  className="grid gap-3"
                >
                  <label className="grid gap-1 text-sm">
                    <span>Name</span>
                    <Input name="name" required placeholder="Your name"/>
                  </label>
                  <label className="grid gap-1 text-sm">
                    <span>Email</span>
                    <Input name="email" type="email" required placeholder="you@example.com"/>
                  </label>
                  <label className="grid gap-1 text-sm">
                    <span>Message</span>
                    <Textarea name="message" placeholder="Tell us a bit about your project..." rows={5}/>
                  </label>
                  <Button type="submit" className="mt-2">Send</Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <footer className="border-t border-black/5 dark:border-white/10 py-10">
        <div className="container">
          <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
            <p className="text-sm opacity-80">© {new Date().getFullYear()} ABVAVRG Holdings, LLC. All rights reserved.</p>
            <div className="flex items-center gap-4 text-sm">
              <a className="underline" href="#privacy">Privacy</a>
              <span className="opacity-30">•</span>
              <a className="underline" href="#terms">Terms</a>
              <span className="opacity-30">•</span>
              <a className="underline" href="https://instagram.com/" target="_blank" rel="noreferrer">Instagram</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Feature({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-0.5 grid h-9 w-9 place-items-center rounded-xl bg-amber-400/15 text-amber-700 dark:text-amber-300">
        {icon}
      </div>
      <div>
        <h3 className="text-sm font-semibold">{title}</h3>
        <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300">{text}</p>
      </div>
    </div>
  );
}

function Venture({ icon, name, blurb, tags }: { icon: React.ReactNode; name: string; blurb: string; tags: string[] }) {
  return (
    <Card className="group border-black/5 bg-white/70 backdrop-blur transition-colors hover:bg-white dark:bg-neutral-900/50 dark:hover:bg-neutral-900 dark:border-white/10">
      <CardHeader className="space-y-3">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900">
            {icon}
          </div>
          <CardTitle className="text-lg">{name}</CardTitle>
        </div>
        <div className="flex flex-wrap gap-2">
          {tags.map((t) => (
            <span key={t} className="rounded-full border border-black/5 px-2 py-1 text-xs text-neutral-600 dark:text-neutral-300 dark:border-white/10">
              {t}
            </span>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-neutral-600 dark:text-neutral-300">{blurb}</p>
      </CardContent>
    </Card>
  );
}

function PlaceholderVenture() {
  return (
    <Card className="border-dashed border-2 border-amber-400/40 bg-amber-50/20 dark:bg-amber-400/5">
      <CardHeader>
        <CardTitle className="text-base">Your next idea</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-neutral-600 dark:text-neutral-300">Have a concept that fits the ABVAVRG ethos? <a href="#contact" className="underline text-amber-700 dark:text-amber-300">Pitch it</a> and let’s co‑build.</p>
      </CardContent>
    </Card>
  );
}
