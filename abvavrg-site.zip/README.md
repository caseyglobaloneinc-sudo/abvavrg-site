# ABVAVRG — website

A minimal Next.js + Tailwind single-page marketing site for ABVAVRG.

## Dev
```bash
npm install
npm run dev
```

## Deploy
Connect the repo to Vercel and deploy.
